package com.cg.hr.controllers;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hr.dtos.Employee;
import com.cg.hr.exception.EmpException;
import com.cg.hr.services.EmpService;


@Controller

public class EmpCrudController {
	
	@Resource
	private EmpService service;
	
	@RequestMapping("/getHomePage.do")
	public ModelAndView getHomePAge()
	{
		ModelAndView mAndV =new ModelAndView("HomePage");
		return mAndV;
		
		
	}
	
	@RequestMapping("/getEmpList.do")
	public ModelAndView getEmpList() throws EmpException
	{
		
		List<Employee> empList =service.getEmpList();
		ModelAndView mAndV =new ModelAndView();
		mAndV.addObject("empList",empList);
		mAndV.addObject("pageHead", "Employee List");
		mAndV.setViewName("EmpList");
		return mAndV;
	}
	
	
	@RequestMapping("/getEmpDetails.do")
	public ModelAndView getEmpDetails(@RequestParam("empNo")int empNo) throws EmpException
	{
		Employee emp=service.getEmpOnId(empNo);
		ModelAndView mAndV =new ModelAndView();
		mAndV.addObject("emp",emp);
		mAndV.addObject("pageHead", "Employee Details");
		mAndV.setViewName("EmpDetails");
		return mAndV;
	}

	@RequestMapping("/getEntryPage.do")
	public ModelAndView getEntryPAge()
	{
		ModelAndView mAndV =new ModelAndView("EntryPage");
		Employee emp=new Employee();//command object
		mAndV.addObject("employee", emp);
		return mAndV;
	}
	
	@RequestMapping(value="/submitEmpDetails.do" , method=RequestMethod.POST)
	public String submitEmpDetails(@ModelAttribute("employee")Employee emp, Model mAndV) throws EmpException
	{
		System.out.println(emp);
		
		service.inserNewEmp(emp);
		
		
		mAndV.addAttribute("emp",emp);
		mAndV.addAttribute("pageHead", "Successful joining of employee");
		//mAndV.setViewName("SuccEmpJoining");
		return "SuccEmpJoining";
	}
	@RequestMapping("/getUpdateNamePage.do")
	public ModelAndView getUpdateNamePage() throws EmpException
	{
		ModelAndView mAndV =new ModelAndView("getUpdateNamePage");
		List<Integer> idList =service.getEmpNoList();
		mAndV.addObject("pageHead", "update name of a employee");
		
		mAndV.addObject("idList", idList); 
		return mAndV;
	}
	@RequestMapping(value="/submitNewEmpName.do" , method=RequestMethod.GET)
	public String submitNewEmpName(@RequestParam("")int empNo,@RequestParam("") String newName,Model mAndV) throws EmpException
	{
		System.out.println(empNo+" "+newName);
		
		service.updateEmpName(empNo, newName);
		
		Employee emp=service.getEmpOnId(empNo);
		mAndV.addAttribute("emp",emp);
		mAndV.addAttribute("pageHead", "Successful updating of employee");
		//mAndV.setViewName("SuccEmpJoining");
		return "SuccEmpUpdate";
	}
	

}
