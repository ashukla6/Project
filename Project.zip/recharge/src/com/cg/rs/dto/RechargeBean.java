package com.cg.rs.dto;

public class RechargeBean {
	private int rechargeid;
	public int getRechargeid() {
		return rechargeid;
	}
	public void setRechargeid(int rechargeid) {
		this.rechargeid = rechargeid;
	}
	public String getPackagename() {
		return packagename;
	}
	public void setPackagename(String packagename) {
		this.packagename = packagename;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getValidity() {
		return validity;
	}
	public void setValidity(int validity) {
		this.validity = validity;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	private String packagename;
	private int amount;
	private int validity;
	private int discount;
	@Override
	public String toString() {
		return "RechargeBean [rechargeid=" + rechargeid + ", packagename="
				+ packagename + ", amount=" + amount + ", validity=" + validity
				+ ", discount=" + discount + "]";
	}
	public RechargeBean(String packagename, int amount, int validity,
			int discount) {
		super();
		this.packagename = packagename;
		this.amount = amount;
		this.validity = validity;
		this.discount = discount;
	}
	public RechargeBean() {
	}
	}
	


