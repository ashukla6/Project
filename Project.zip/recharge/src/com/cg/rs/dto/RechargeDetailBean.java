package com.cg.rs.dto;

public class RechargeDetailBean {

	public RechargeDetailBean() {
		// TODO Auto-generated constructor stub
	}
 public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public float getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(float phoneno) {
		this.phoneno = phoneno;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getPackagename() {
		return packagename;
	}
	public void setPackagename(String packagename) {
		this.packagename = packagename;
	}
 private int custid;
 private String custname;
 private float phoneno;
 private int amount;
 private String packagename;
 
 
}
