package com.cg.rs.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cg.rs.dto.RechargeBean;
import com.cg.rs.exception.RechargeException;
import com.cg.rs.service.IRechargeService;
import com.cg.rs.service.RechargeService;


@WebServlet("/RechargeServelet2")
public class RechargeServelet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RechargeServelet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("id"));
		IRechargeService RechargeService = null;
		RechargeBean donor = null;
		String target = "";
		

		HttpSession session = request.getSession(true);
		// Object creations
		
		RechargeService = new RechargeService();
		donor=new RechargeBean();
		String targets="view/Recharge.jsp";
		String targetError = "view/error.jsp";
		try {
			donor = RechargeService.getDonor(id);
		} catch (RechargeException e) {
			session.setAttribute("error", e.getMessage());
			target = targetError;
		}
		if (donor.getRechargeid() != 0) {
			session.setAttribute("error", null);
			session.setAttribute("donor", donor);
			target = targets;
		} else {
			session.setAttribute("donor", null);
			session.setAttribute("error",
					"Sorry No data Found for given ID!");
			target = targetError;
		}

	
	

	RequestDispatcher dispatcher = request.getRequestDispatcher(targets);
	dispatcher.forward(request, response);
	}

}
