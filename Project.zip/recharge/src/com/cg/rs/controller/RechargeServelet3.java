package com.cg.rs.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.rs.dto.RechargeBean;
import com.cg.rs.dto.RechargeDetailBean;
import com.cg.rs.exception.RechargeException;
import com.cg.rs.service.IRechargeService;
import com.cg.rs.service.RechargeService;

/**
 * Servlet implementation class RechargeServelet3
 */
@WebServlet("/RechargeServelet3")
public class RechargeServelet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RechargeServelet3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		IRechargeService RechargeService = null;
		RechargeDetailBean Recharge = null;
		String target = "";
		String targetError=null;
		HttpSession session = request.getSession(true);
		// Object creations
		RechargeBean rec1=new RechargeBean();
		
		Recharge = new RechargeDetailBean();
		RechargeService = new RechargeService();
		int custId = 0;
		String targetAdd = "view/Success.jsp";
		List<String> errorList = new ArrayList<String>();

		String custName =request.getParameter("username").trim();
		float phoneno=Float.parseFloat(request.getParameter("phoneno"));
	   rec1=(RechargeBean)request.getSession().getAttribute("donor");
	   System.out.println(rec1);
        int amt = rec1.getAmount();
        int validity=rec1.getValidity();
        String packagename=rec1.getPackagename();
		Recharge.setCustname(custName);
		Recharge.setPhoneno(phoneno);
		Recharge.setAmount(amt);
		Recharge.setPackagename(packagename);
	

		
		

		if (errorList.isEmpty()) {
			/************ Code for Adding donation Details **************/
			try {
				custId = RechargeService.add(Recharge);
			} catch (RechargeException e) {
				session.setAttribute("error", e.getMessage());
				target = targetError;
			}
			if (custId != 0) {
				Recharge.setCustid(custId);

				// set ID to display ID alone
				// session.setAttribute("donorId", donorId);
				session.setAttribute("Recharge", Recharge);
				target = "view/Success.jsp";
				System.out.println(target);
			}

		} else {
			session.setAttribute("errorList", errorList);
			target = targetAdd;
		}
		
	
	RequestDispatcher dispatcher = request.getRequestDispatcher(target);
	dispatcher.forward(request, response);
	}
}
