package com.cg.rs.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.cg.rs.dto.RechargeBean;
import com.cg.rs.exception.RechargeException;
import com.cg.rs.service.IRechargeService;
import com.cg.rs.service.RechargeService;


@WebServlet("/RechargeServelet")
public class RechargeServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public RechargeServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("In doPost");
		IRechargeService RechargeService = null;
		RechargeBean donor = null;
		String target = "";
		

		HttpSession session = request.getSession(true);
		// Object creations
		donor = new RechargeBean();
		RechargeService = new RechargeService();
		
		String targetViewAll = "view/viewAllRecharge.jsp";
		String targetError = "view/error.jsp";
		List<RechargeBean> RechargeList = null;
		try {
			RechargeList = RechargeService.getAllRecharge();
		} catch (RechargeException e) {
			session.setAttribute("error", e.getMessage());
			target = targetError;
		}
		if (!RechargeList.isEmpty()) {
			session.setAttribute("error", null);
			session.setAttribute("RechargeList", RechargeList);
			target = targetViewAll;
		
		} else {
			session.setAttribute("RechargeList", null);
			session.setAttribute("error", "Sorry No data Found!");
			target = targetViewAll;
			
		}

	
	

	RequestDispatcher dispatcher = request.getRequestDispatcher(target);
	dispatcher.forward(request, response);
	
}

	}


