package com.cg.rs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.rs.dao.IRechargeDao;
import com.cg.rs.dao.RechargeDao;
import com.cg.rs.dto.RechargeBean;
import com.cg.rs.dto.RechargeDetailBean;
import com.cg.rs.exception.RechargeException;

public class RechargeService implements IRechargeService {

	IRechargeDao dao=new RechargeDao();
	@Override
	public List<RechargeBean> getAllRecharge() throws RechargeException {
		// TODO Auto-generated method stub
		System.out.println("In Service");
		return dao.getAllRecharge();
		
	
	}
	@Override
	public RechargeBean getDonor(int rechargeid) throws RechargeException {
		// TODO Auto-generated method stub
		return dao.getDonor(rechargeid);
	}
	@Override
	public int add(RechargeDetailBean donor) throws RechargeException {
		// TODO Auto-generated method stub
	return dao.add(donor);
	}

}
