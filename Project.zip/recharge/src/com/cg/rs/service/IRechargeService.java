package com.cg.rs.service;

import java.util.List;



import com.cg.rs.dto.RechargeBean;
import com.cg.rs.dto.RechargeDetailBean;
import com.cg.rs.exception.RechargeException;

public interface IRechargeService {
	public List<RechargeBean> getAllRecharge()throws RechargeException;
	public RechargeBean getDonor(int rechargeid) throws RechargeException;
	public int add(RechargeDetailBean donor) throws RechargeException;

}
