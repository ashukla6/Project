package com.cg.rs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.cg.rs.dto.RechargeBean;
import com.cg.rs.dto.RechargeDetailBean;
import com.cg.rs.exception.RechargeException;
import com.cg.rs.utility.DbConnection;

public class RechargeDao implements IRechargeDao {
	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;


	public RechargeDao() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<RechargeBean> getAllRecharge() throws RechargeException {
		System.out.println("In DAO");
		// TODO Auto-generated method stub
		List<RechargeBean> list = new ArrayList<RechargeBean>();
		RechargeBean dto = new RechargeBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapperSql.VIEWALL);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				dto.setRechargeid(resultSet.getInt(1));
				dto.setPackagename(resultSet.getString(2));
				dto.setAmount(resultSet.getInt(3));
				dto.setValidity(resultSet.getInt(4));
				dto.setDiscount(resultSet.getInt(5));
				
				list.add(dto);
				 
					
			 dto = new RechargeBean();
			
			}
		} catch (SQLException e) {
			throw new RechargeException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new RechargeException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new RechargeException(
						"Could not close the connection");
			}
		}
		return list;
	
	}

	@Override
	public RechargeBean getDonor(int rechargeid) throws RechargeException {
		// TODO Auto-generated method stub
		RechargeBean dto = new RechargeBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapperSql.VIEW);
			preparedStatement.setInt(1, rechargeid);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				dto.setRechargeid(resultSet.getInt(1));
				dto.setPackagename(resultSet.getString(2));
				dto.setAmount(resultSet.getInt(3));
				dto.setValidity(resultSet.getInt(4));
				dto.setDiscount(resultSet.getInt(5));
				// Convert SQL to Calendar Date
				// Date date = resultSet.getDate(6);
				/*
				 * Calendar cDate = Calendar.getInstance(); cDate.setTime(date);
				 */
				//dto.setDonationDate(resultSet.getDate(6).toLocalDate());
			}

		} catch (SQLException e) {
			throw new RechargeException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new RechargeException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new RechargeException(
						"Could not close the connection");
			}
		}
		return dto;
	}

	@Override
	public int add(RechargeDetailBean donor) throws RechargeException {
		int result = 0;
		int sequence = 0;
		try {
			conn = DbConnection.getConnection();
			
			preparedStatement = conn
					.prepareStatement(IQueryMapperSql.GETSEQUENCEID);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				sequence = resultSet.getInt(1);
			} else {
				sequence = 0;
			}
			if (sequence != 0) {

				preparedStatement = conn
						.prepareStatement(IQueryMapperSql.INSERTQUERY);
				preparedStatement.setInt(1, sequence);
				preparedStatement.setString(2, donor.getCustname());
				preparedStatement.setFloat(3, donor.getPhoneno());
				preparedStatement.setInt(4, donor.getAmount());
				preparedStatement.setString(5,donor.getPackagename());
				result = preparedStatement.executeUpdate();

				if (result == 0) {
					return 0;
				}
			}

		} catch (SQLException e) {
			throw new RechargeException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new RechargeException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new RechargeException(
						"Could not close the connection");
			}
		}
		return sequence;
	}
	}


