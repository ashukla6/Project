package com.cg.rs.dao;

public interface IQueryMapperSql {
	String VIEWALL = "SELECT rechargeid, packagename, amount, validity, discount FROM recharge";
	String VIEW = "SELECT rechargeid, packagename, amount, validity, discount FROM recharge WHERE rechargeid=?";
	String GETSEQUENCEID = "SELECT autocustid.NEXTVAL FROM dual";
	String INSERTQUERY="INSERT INTO rechargedetail VALUES(?,?,?,?,?)";
}
