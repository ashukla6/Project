package com.cg.rs.dao;

import java.util.List;



import com.cg.rs.dto.RechargeBean;
import com.cg.rs.dto.RechargeDetailBean;
import com.cg.rs.exception.RechargeException;



public interface IRechargeDao {
	public List<RechargeBean> getAllRecharge()throws RechargeException;
	public RechargeBean getDonor(int rechargeid) throws RechargeException;
	public int add(RechargeDetailBean donor) throws RechargeException;
}
