package com.cg.bean;

public class ElectricityBean {

	public ElectricityBean() {
		// TODO Auto-generated constructor stub
	}
 public long getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(long consumerNum) {
		this.consumerNum = consumerNum;
	}
	public String getConsumerName() {
		return consumerName;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

 public ElectricityBean(long consumerNum, String consumerName, String address) {
	super();
	this.consumerNum = consumerNum;
	this.consumerName = consumerName;
	this.address = address;
}

 @Override
public String toString() {
	return "ElectricityBean [consumerNum=" + consumerNum + ", consumerName="
			+ consumerName + ", address=" + address + "]";
}
 private long consumerNum;
private String consumerName;
 private String address;
}
