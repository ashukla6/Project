package com.cg.bean;

import java.util.Date;

public class ConsumerBean {

	public ConsumerBean() {
		// TODO Auto-generated constructor stub
	}
	
	public ConsumerBean(long consumerNum, int curReading, int unitConsumed,
			int netAmount) {
		super();
		this.consumerNum = consumerNum;
		this.curReading = curReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
	}
	private int billNum;
	@Override
	public String toString() {
		return "ConsumerBean [billNum=" + billNum + ", consumerNum="
				+ consumerNum + ", curReading=" + curReading
				+ ", unitConsumed=" + unitConsumed + ", netAmount=" + netAmount
				+ ", billdate=" + billdate + "]";
	}
	private long consumerNum;
	private int curReading;
	private int unitConsumed;
	private int netAmount;
	private Date billdate;
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public long getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(long consumerNum) {
		this.consumerNum = consumerNum;
	}
	public int getCurReading() {
		return curReading;
	}
	public void setCurReading(int curReading) {
		this.curReading = curReading;
	}
	public int getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(int unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public int getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(int netAmount) {
		this.netAmount = netAmount;
	}
	public Date getBilldate() {
		return billdate;
	}
	public void setBilldate(Date billdate) {
		this.billdate = billdate;
	}
	
}
