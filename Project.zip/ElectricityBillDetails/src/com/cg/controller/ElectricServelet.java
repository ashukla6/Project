package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.ElectricityBean;

import com.cg.exception.BillException;
import com.cg.services.ElectricServiceImpl;
import com.cg.services.IElectricService;


@WebServlet("*.do")
public class ElectricServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ElectricServelet() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		HttpSession session = request.getSession(true);
		String path = request.getServletPath().trim();
		
		IElectricService service = new ElectricServiceImpl(); 
		ElectricityBean electric=new ElectricityBean();
		List<ElectricityBean> list = new ArrayList<ElectricityBean>();
		
		String target="";
		switch(path)
		{
		
		case "/login.do":
		{
		String username=request.getParameter("username");
		String password= request.getParameter("password");
		System.out.println(username);
		System.out.println(password);
		
		if(username.equals("abhi") && (password.equals("1234")))
		{
			target="select.jsp";
		}
		else
		{
			target="login.jsp";
			String error= "Invalid username and password";
			session.setAttribute("error", error);
			
		}
		break;
		}
		
		case "/view.do":
		{
			try {
				list = service.getDetails();
				System.out.println("jakldj");
				System.out.println(list);
				session.setAttribute("list", list);
				target = "list.jsp";
					
				
			} catch (BillException e) {
				session.setAttribute("error", e.getMessage());
				target = "error.jsp";
			}
			break;
			
		}
		//case 1
		case "/proceed.do":
		{
			String custNum=request.getParameter("id");
			long Num=Long.parseLong(custNum);
			try {
				list = service.search(Num);
				System.out.println("jakldj");
				System.out.println(list);
				session.setAttribute("list", list);
				target = "list.jsp";
					
				
			} catch (BillException e) {
				session.setAttribute("error", e.getMessage());
				target = "error.jsp";
			}
			break;
			
			
			
		}
		
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

}
