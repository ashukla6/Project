package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.ConsumerBean;
import com.cg.bean.ElectricityBean;
import com.cg.exception.BillException;
import com.cg.utility.DbConnection;

public class ElectricDaoImpl implements IElectricDao {
	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;


	public ElectricDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<ElectricityBean> getDetails() throws BillException {
		// TODO Auto-generated method stub
		List<ElectricityBean> list = new ArrayList<ElectricityBean>();
		ElectricityBean bean = new ElectricityBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQuerryMapper.view);
			System.out.println("in dao");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				
				bean.setConsumerNum(resultSet.getLong(1));
				bean.setConsumerName(resultSet.getString(2));
				bean.setAddress(resultSet.getString(3));
				
				list.add(bean);
				bean = new ElectricityBean();
				
			
			
			}
			

		} catch (SQLException e) {
			throw new BillException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new BillException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new BillException(
						"Could not close the connection");
			}
		}
		System.out.println(list);
	
		if(list.isEmpty())
			throw new BillException("City/Movie name not found");
		
		return list;
		
		
		
	}

	@Override
	public List<ElectricityBean> search(long consumerNum) throws BillException {
		// TODO Auto-generated method stub
		
		
		List<ElectricityBean> list = new ArrayList<ElectricityBean>();
		ElectricityBean bean = new ElectricityBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQuerryMapper.search);
			System.out.println("in dao");
			
			preparedStatement.setLong(1, consumerNum);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				
				bean.setConsumerNum(resultSet.getLong(1));
				bean.setConsumerName(resultSet.getString(2));
				bean.setAddress(resultSet.getString(3));
				
				list.add(bean);
				bean = new ElectricityBean();
				
			
			
			}
			

		} catch (SQLException e) {
			throw new BillException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new BillException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new BillException(
						"Could not close the connection");
			}
		}
		System.out.println(list);
	
		if(list.isEmpty())
			throw new BillException("Bill name not found");
		
		return list;
	
	}
	private int getPatientId() throws BillException 
	{
		// TODO Auto-generated method stub
		int patientId = 0;
		String sql = "SELECT Patient_Id_Sequence.NEXTVAL FROM DUAL";
		try
		{
			PreparedStatement pstmt= conn.prepareStatement(sql);
				ResultSet res = pstmt.executeQuery();
				if(res.next())
				{
					patientId = res.getInt(1);
				}
		}
		catch(SQLException e)
		{
			
			throw new BillException(
					"Could not close the connection");
		}
		return patientId;		
		
	}

	@Override
	public List<ConsumerBean> show(long consumerNum) throws BillException {
		// TODO Auto-generated method stub
		List<ConsumerBean> list = new ArrayList<ConsumerBean>();
		ConsumerBean bean = new ConsumerBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQuerryMapper.search1);
			System.out.println("in dao");
			
			preparedStatement.setLong(1, consumerNum);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				
				bean.setBillNum(resultSet.getInt(1));
				bean.setBilldate(resultSet.getDate(2));
				bean.setCurReading(resultSet.getInt(3));
				
				list.add(bean);
				bean = new ElectricityBean();
				
			
			
			}
			

		} catch (SQLException e) {
			throw new BillException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new BillException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new BillException(
						"Could not close the connection");
			}
		}
		System.out.println(list);
	
		if(list.isEmpty())
			throw new BillException("Bill name not found");
		
		return list;
	
	}

}
