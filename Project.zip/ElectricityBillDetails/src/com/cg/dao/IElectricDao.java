package com.cg.dao;

import java.util.List;



import com.cg.bean.ConsumerBean;
import com.cg.bean.ElectricityBean;
import com.cg.exception.BillException;



public interface IElectricDao {
	public List<ElectricityBean> getDetails() throws BillException;
	public List<ElectricityBean> search(long consumerNum) throws BillException;
	public List<ConsumerBean> show(long consumerNum) throws BillException;
	
	
	
	

}
