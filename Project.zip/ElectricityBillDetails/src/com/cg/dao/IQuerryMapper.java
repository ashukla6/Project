package com.cg.dao;

public interface IQuerryMapper {
	
	 String view="select * from consumers";
	 String search=" select * from consumers where consumer_num=?";
	 String search1="select * from billdetails where consumer_num=?";
	 

}
