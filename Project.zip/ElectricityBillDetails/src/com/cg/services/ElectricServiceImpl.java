package com.cg.services;

import java.util.List;

import com.cg.bean.ConsumerBean;
import com.cg.bean.ElectricityBean;
import com.cg.dao.ElectricDaoImpl;
import com.cg.dao.IElectricDao;
import com.cg.exception.BillException;

public class ElectricServiceImpl implements IElectricService {
	
	
	IElectricDao dao=null;
	
	

	public ElectricServiceImpl() {
		dao=new ElectricDaoImpl();
	}

	@Override
	public List<ElectricityBean> getDetails() throws BillException {
		// TODO Auto-generated method stub
		return dao.getDetails();
	}

	@Override
	public List<ElectricityBean> search(long consumerNum) throws BillException {
		// TODO Auto-generated method stub
		return null;
	}

}
