package com.cg.services;

import java.util.List;

import com.cg.bean.ConsumerBean;
import com.cg.bean.ElectricityBean;
import com.cg.exception.BillException;

public interface IElectricService {
	public List<ElectricityBean> getDetails() throws BillException;
	public List<ElectricityBean> search(long consumerNum) throws BillException;

}
