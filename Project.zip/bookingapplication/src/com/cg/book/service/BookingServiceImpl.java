package com.cg.book.service;

import java.util.List;

import com.cg.book.bean.BookingBean;
import com.cg.book.dao.BookingDaoImpl;
import com.cg.book.dao.IBookingDao;
import com.cg.book.exception.BookingException;


public class BookingServiceImpl implements BookingService {

	IBookingDao dao=new BookingDaoImpl();

	@Override
	public List<BookingBean> getBooking(String movie, String city)
			throws BookingException {
		// TODO Auto-generated method stub
		System.out.println("In service");
		return dao.getBooking(movie,city);
	}

	@Override
	public void updatetable(String id) throws BookingException {
		// TODO Auto-generated method stub
		dao.updatetable(id);
	}

}
