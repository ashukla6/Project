package com.cg.book.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.cg.book.bean.BookingBean;
import com.cg.book.exception.BookingException;
import com.cg.book.service.BookingService;
import com.cg.book.service.BookingServiceImpl;


/**
 * Servlet implementation class BookingServelet
 */
@WebServlet("*.do")
public class BookingServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookingServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		String path = request.getServletPath().trim();
		String city=null;
		String movie=null;
		BookingService bookingService = new BookingServiceImpl(); 
		BookingBean booking=new BookingBean();
		List<BookingBean> list = new ArrayList<BookingBean>();
		String targets="MovieDetails.jsp";
		String targetError = "Failure.jsp";
		String targetSuccess = "Success.jsp";
		String target = "";
		switch(path)
		{
		
		case "/booknow.do":

		city=request.getParameter("city");
		System.out.println(city);
		movie=request.getParameter("movie");
		System.out.println(movie);
		
		//BookingBean booking = null;
		
		System.out.println("In servelet");

		//HttpSession session = request.getSession(true);
		
	
		//List<BookingBean> booking = new BookingBean<>();
		
		
		
		try {
			list = bookingService.getBooking(movie,city);
			System.out.println("jakldj");
			System.out.println(list);
			session.setAttribute("booking", list);
			target = targets;
				
			
		} catch (BookingException e) {
			session.setAttribute("error", e.getMessage());
			target = targetError;
		}
		break;
		case "/proceed.do":  
		String id=request.getParameter("id");
		try {
			 bookingService.updatetable(id);
			System.out.println("jakldj");
			session.setAttribute("id",id);
			target = targetSuccess;
			
		} catch (BookingException e) {
			session.setAttribute("error", e.getMessage());
			target = targetError;
		}
		
			break;
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
		
		}
		}

