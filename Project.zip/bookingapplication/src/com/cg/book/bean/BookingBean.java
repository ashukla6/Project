package com.cg.book.bean;

public class BookingBean {

	public BookingBean() {
		// TODO Auto-generated constructor stub
	}
	private String movieId;
	private String movie;
	private String theatre;
	private String location;
	private String city;
	private String time;
	private String status;
	public String getMovieId() {
		return movieId;
	}
	@Override
	public String toString() {
		return "BookingBean [movieId=" + movieId + ", movie=" + movie
				+ ", theatre=" + theatre + ", location=" + location + ", city="
				+ city + ", time=" + time + ", status=" + status + "]";
	}
	public void setMovieId(String movieId) {
		this.movieId = movieId;
	}
	public String getMovie() {
		return movie;
	}
	public void setMovie(String movie) {
		this.movie = movie;
	}
	public String getTheatre() {
		return theatre;
	}
	public void setTheatre(String theatre) {
		this.theatre = theatre;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public BookingBean(String movie, String theatre, String location,
			String city, String time, String status) {
		super();
		this.movie = movie;
		this.theatre = theatre;
		this.location = location;
		this.city = city;
		this.time = time;
		this.status = status;
	}
	public BookingBean(String movieId, String movie, String theatre,
			String location, String city, String time, String status) {
		super();
		this.movieId = movieId;
		this.movie = movie;
		this.theatre = theatre;
		this.location = location;
		this.city = city;
		this.time = time;
		this.status = status;
	}
	

}
