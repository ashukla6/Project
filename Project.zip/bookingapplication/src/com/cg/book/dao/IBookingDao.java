
package com.cg.book.dao;

import java.util.List;

import com.cg.book.bean.BookingBean;
import com.cg.book.exception.BookingException;


public interface IBookingDao {
	public List< BookingBean> getBooking(String movie,String city) throws BookingException;
	public void updatetable(String id) throws BookingException;
	
	
}
