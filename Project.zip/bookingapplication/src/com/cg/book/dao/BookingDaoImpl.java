package com.cg.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




import javax.servlet.RequestDispatcher;

import com.cg.book.bean.BookingBean;
import com.cg.book.exception.BookingException;
import com.cg.book.utility.DbConnection;

public class BookingDaoImpl implements IBookingDao {
	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;


	@Override
	public List<BookingBean> getBooking(String movie, String city)
			throws BookingException {
		// TODO Auto-generated method stub
		List<BookingBean> list = new ArrayList<BookingBean>();
		BookingBean dto = new BookingBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQuerryMapper.VIEW);
			preparedStatement.setString(1, city);
			preparedStatement.setString(2, movie);
			System.out.println("in dao");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				dto.setTheatre(resultSet.getString(1));
				
				dto.setLocation(resultSet.getString(2));
				dto.setTime(resultSet.getString(3));
				dto.setStatus(resultSet.getString(4));
				dto.setMovieId(resultSet.getString(5));
				list.add(dto);
				dto = new BookingBean();
				
			
			
			}
			

		} catch (SQLException e) {
			throw new BookingException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new BookingException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new BookingException(
						"Could not close the connection");
			}
		}
		System.out.println(list);
	
		if(list.isEmpty())
			throw new BookingException("City/Movie name not found");
		return list;
		
		
		
	}


	@Override
	public void updatetable(String id) throws BookingException {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		Connection conn = null;
		System.out.println(id);
		ResultSet resultSet = null;
		try {
			conn =com.cg.book.utility.DbConnection.getConnection();
			String qry1 ="UPDATE movie_master SET status='NotAvailable' where movie_id=? ";
			System.out.println(qry1);
			int recsAff=0;
					PreparedStatement stmt1=conn.prepareStatement(qry1);
					stmt1.setString(1,id);
						 recsAff=stmt1.executeUpdate();
		} catch (BookingException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
		
	}

}
