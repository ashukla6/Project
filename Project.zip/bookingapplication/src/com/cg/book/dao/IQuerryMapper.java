package com.cg.book.dao;

public interface IQuerryMapper {
	String VIEW = "SELECT theatre_name, theatre_location, show_timing, status,movie_id  FROM movie_master WHERE city =? and movie_name=?";
	String UPDATE="UPDATE movie_master SET status='NotAvailable' where movie_id=?";

}
