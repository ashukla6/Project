DROP TABLE calltypemaster cascade constraints;


CREATE TABLE calltypemaster(calltypeid varchar2(20),
Description varchar2(40));

INSERT into calltypemaster values('1','Network coverage not available');
INSERT into calltypemaster values('2','Unable to connect to the network');
INSERT into calltypemaster values('3','Increase usage limit');
INSERT into calltypemaster values('4','Bill not received');
INSERT into calltypemaster values('5','Conversion plan Postpaid to Prepaid');
INSERT into calltypemaster values('6','Conversion plan Prepaid to Postpaid');

DROP TABLE calldetails cascade constraints;

CREATE TABLE calldetails(
callno number(4),
calltype varchar2(40),
Description varchar2(40)
);


DROP SEQUENCE call_id_seq;



CREATE SEQUENCE call_id_deq
START WITH 1 increment by 1;
