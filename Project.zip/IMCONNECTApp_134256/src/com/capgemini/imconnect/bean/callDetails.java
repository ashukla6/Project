package com.capgemini.imconnect.bean;

public class callDetails
{
	
	private int callNo;
	private String callType;
	private String Description;
	public int getCallNo() {
		return callNo;
	}
	public void setCallNo(int callNo) {
		this.callNo = callNo;
	}
	public String getCallType() {
		return callType;
	}
	public void setCallType(String callType) {
		this.callType = callType;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public callDetails()
	{
		
	}
	public callDetails(int callNo, String callType, String description) {
		
		this.callNo = callNo;
		this.callType = callType;
		Description = description;
	}
	
	
	
	public callDetails(String callType, String description) {
		super();
		this.callType = callType;
		Description = description;
	}
	@Override
	public String toString() {
		return "callDetails [callNo=" + callNo + ", callType=" + callType
				+ ", Description=" + Description + "]";
	}
	
	
	
}
