package com.capgemini.imconnect.bean;

public class CallType
{
	private String callTypeId;
	private String description;
	public String getCallTypeId() {
		return callTypeId;
	}
	public void setCallTypeId(String callTypeId) {
		this.callTypeId = callTypeId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	public CallType()
	{
		
	}
	public CallType(String description) {
		super();
		this.description = description;
	}
	@Override
	public String toString() {
		return "CallType [callTypeId=" + callTypeId + ", description="
				+ description + "]";
	}
	
	
}
