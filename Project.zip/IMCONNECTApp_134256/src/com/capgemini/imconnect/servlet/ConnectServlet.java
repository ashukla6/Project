package com.capgemini.imconnect.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.imconnect.bean.callDetails;
import com.capgemini.imconnect.exception.IMConnectException;
import com.capgemini.imconnect.services.IMConnectService;
import com.capgemini.imconnect.services.IMConnectServiceImpl;


@WebServlet("/ConnectServlet")
public class ConnectServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
   
    public ConnectServlet() 
    {
       
    }

	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("In post");
		RequestDispatcher dispatcher;
		callDetails call = null;
		String action = request.getParameter("action");
		IMConnectService service = new IMConnectServiceImpl();
		ArrayList<String> callTypes = new ArrayList<String>();
		switch(action)
		{
		
		case "Login":
			System.out.println("In Login case");
			String userName = request.getParameter("username");
			String role     = request.getParameter("role");
			HttpSession session = request.getSession(true);
			if(role.equals("EMP"))
			{
				
				session.setAttribute("username", userName);
				
			try 
			{
				callTypes=service.getallCallType();
				System.out.println(callTypes);
				request.setAttribute("calltypes",callTypes);
				dispatcher = 
						request.getRequestDispatcher("Emp.jsp");
						
				
						dispatcher.forward(request,response);
			}
			catch (IMConnectException e)
			{
				
				String errorMessage = e.getMessage();
				request.setAttribute("errMsg", errorMessage);
				dispatcher = 
						request.getRequestDispatcher("error.jsp");
						
						dispatcher.forward(request,response);
			}
			
			}
			else
			{
				session.setAttribute("username",userName);
				dispatcher = 
						request.getRequestDispatcher("ITIM.jsp");
						
						dispatcher.forward(request,response);
			}
				
			
			break;
			
			
			
		case "SubmitQuery":
			String name = request.getParameter("callType");
			
			String description = request.getParameter("description");
			
			call = new callDetails(name,description);
			
			try 
			{
				int callNo = service.addCalldetails(call);
				request.setAttribute("callNo",callNo);
				dispatcher = 
						request.getRequestDispatcher("success.jsp");
						
				
						dispatcher.forward(request,response);
			} 
			catch (IMConnectException e) 
			{
				String errorMessage = e.getMessage();
				request.setAttribute("errMsg", errorMessage);
				dispatcher = 
						request.getRequestDispatcher("error.jsp");
						
						dispatcher.forward(request,response);
			}
			
			
			break;
		}
	}

}
