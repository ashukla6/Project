package com.capgemini.imconnect.services;

import java.util.ArrayList;

import com.capgemini.imconnect.bean.callDetails;
import com.capgemini.imconnect.dao.IMConnectDao;
import com.capgemini.imconnect.dao.IMConnectDaoImpl;
import com.capgemini.imconnect.exception.IMConnectException;

public class IMConnectServiceImpl implements IMConnectService{

	IMConnectDao dao;
	
	public  IMConnectServiceImpl()
	{
		dao = new IMConnectDaoImpl();
	}
	@Override
	public ArrayList<String> getallCallType() throws IMConnectException {
		// TODO Auto-generated method stub
		return dao.getallCallType();
	}
	
	@Override
	public int addCalldetails(callDetails call) throws IMConnectException {
		// TODO Auto-generated method stub
		return dao.addCalldetails(call);
	}

}
