package com.capgemini.imconnect.services;

import java.util.ArrayList;

import com.capgemini.imconnect.bean.callDetails;
import com.capgemini.imconnect.exception.IMConnectException;

public interface IMConnectService
{
	ArrayList<String> getallCallType() throws IMConnectException;
	int addCalldetails(callDetails call) throws IMConnectException;
}
