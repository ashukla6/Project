package com.capgemini.imconnect.dao;

import java.util.ArrayList;

import com.capgemini.imconnect.bean.callDetails;
import com.capgemini.imconnect.exception.IMConnectException;

public interface IMConnectDao 
{
	ArrayList<String> getallCallType() throws IMConnectException;
	int addCalldetails(callDetails call) throws IMConnectException;
}
