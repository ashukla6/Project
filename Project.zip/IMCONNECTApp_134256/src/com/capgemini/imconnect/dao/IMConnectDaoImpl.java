package com.capgemini.imconnect.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.capgemini.imconnect.bean.callDetails;
import com.capgemini.imconnect.exception.IMConnectException;
import com.capgemini.imconnect.util.DButil;


public class IMConnectDaoImpl implements IMConnectDao{

	@Override
	public ArrayList<String> getallCallType() throws IMConnectException
	{
		
		ArrayList<String> callTypes=null;
		try(Connection con = DButil.getConnection()) 
		{
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("SELECT Description FROM calltypemaster");
			if(res.next()==false)
				throw new IMConnectException("No DAta Found");
			 
			else
			{
				callTypes = new ArrayList<String>();
				do
				{
					String temp = res.getString("Description");
					callTypes.add(temp);
				}
				while(res.next());
			}
			
			
		} 
		catch (Exception e) 
		{
			throw new IMConnectException(e.getMessage());
		}
		return callTypes;
	}

	@Override
	public int addCalldetails(callDetails call) throws IMConnectException 
	{
		
		int callNo = 0;
		try (Connection con = DButil.getConnection())
		{
			Statement stm=con.createStatement();
			ResultSet res=stm.executeQuery("select call_id_deq.nextVal from dual");
					
			if(res.next()==false)
			{
				
				throw new IMConnectException("Could not generate call number.");
			}
			
			callNo=res.getInt(1);
			String callType = call.getCallType();
			String description =call.getDescription();
			PreparedStatement pstm=con.prepareStatement("insert into calldetails values(?,?,?)");
			pstm.setInt(1,callNo);
			pstm.setString(2, callType);
			pstm.setString(3,description);
			
			pstm.execute();
			
		}
		catch (Exception e) 
		{
			throw new IMConnectException("Could not generate call number.");
		}
		
		return callNo;
	}

}
