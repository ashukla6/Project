package com.cg.gc.bean;

public class GameBean {
	
	private String gameName;
	private float gameAmt;
	public GameBean() {
		super();
		
	}
	public GameBean(String gameName, float gameAmt) {
		super();
		this.gameName = gameName;
		this.gameAmt = gameAmt;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public float getGameAmt() {
		return gameAmt;
	}
	public void setGameAmt(float gameAmt) {
		this.gameAmt = gameAmt;
	}
	@Override
	public String toString() {
		return "GameBean [gameName=" + gameName + ", gameAmt=" + gameAmt + "]";
	}
	
	
}
