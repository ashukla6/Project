package com.cg.gc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.gc.bean.GameBean;
import com.cg.gc.bean.UserBean;
import com.cg.gc.exception.GameException;
import com.cg.gc.service.GameCityServiceImpl;
import com.cg.gc.service.IGameCityService;





@WebServlet("*.obj")
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	IGameCityService service;
	private String userName;
	private String userAddress;
	private float cardAmount;
	
    public ProcessUser() {

    	service = new GameCityServiceImpl();
        
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String target="";
		List<GameBean> list = new ArrayList<GameBean>();
		
		HttpSession session = request.getSession(true);
		
		String targetHome = "GameCity.jsp";
		String targetPlay = "Play.jsp";
		String targetError = "Error.jsp";
		String targetTopup = "Topup.jsp";
		String targetSucess = "Success.jsp";
		
		String path = request.getServletPath().trim();
		System.out.println(path);
		
		switch (path) {
		
		
		
		case "/adduser.obj":
			
			userName  = request.getParameter("name");
			userAddress = request.getParameter("address");
			String amount   = request.getParameter("amount");
			cardAmount = (float) (Float.parseFloat(amount)-100.0);
			
			int userid=0;
			System.out.println(userName);
			System.out.println(userAddress);
			System.out.println(amount);
			
			
			UserBean user = new UserBean(userName, userAddress, cardAmount);
			
			try {
				userid = service.addUser(user);
				System.out.println(userid);
			} catch (GameException e) {
				
				session.setAttribute("user", null);
				session.setAttribute("amount", null);
				session.setAttribute("gamelist", list);
				session.setAttribute("error","Something went wrong!! Try Again Later!!");
				target = targetError;
			}
			
			if(userid>0)
			{
				try {
					list = service.showGameList();
					System.out.println(list);
				} catch (GameException e) {
					
					session.setAttribute("error","Something Went Wrong!!");
					target = targetError;
				}
				session.setAttribute("user", user);
				session.setAttribute("amount", cardAmount);
				session.setAttribute("gamelist", list);
				session.setAttribute("error",null);
				target = targetPlay;

			}
			else
			{
				session.setAttribute("user", null);
				session.setAttribute("amount", null);
				session.setAttribute("gamelist", null);
				session.setAttribute("error","No Games Found");
				target = targetError;
			}

			
			break;
			
		case "/play.obj":
			
			String game= request.getParameter("game");
			String gameAmt = request.getParameter("gameAmt");
			float gameAmount = Float.parseFloat(gameAmt);
			String userAmt = request.getParameter("amount");
			float userAmount = Float.parseFloat(userAmt);
			
			if(gameAmount>userAmount)
			{
				
				session.setAttribute("user", null);
				session.setAttribute("amount", userAmount);
				session.setAttribute("game", game);
				session.setAttribute("error",null);
				target = targetTopup;
				
				
			}
			else
			{
				userAmount-=gameAmount;
				session.setAttribute("user", null);
				session.setAttribute("amount", userAmount);
				session.setAttribute("game", game);
				session.setAttribute("error",null);
				target = targetSucess;
					
				
			}
			
			break;
			
			
		}
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.include(request, response);
		
	}

}
