package com.cg.gc.dao;

public interface IQueryMapper {

	String userid = "SELECT seq_users.nextVal FROM dual";
	String adduser = "INSERT INTO users VALUES(?,?,?,?)";
	String showgames = "SELECT * FROM onlinegames";
}
