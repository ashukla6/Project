package com.cg.gc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;






import com.cg.gc.bean.GameBean;
import com.cg.gc.bean.UserBean;
import com.cg.gc.exception.GameException;
import com.cg.gc.util.DbConnection;


public class GameCityDAOImpl implements IGameCityDAO {
	
	
	PreparedStatement preparedStatement = null;
	ResultSet res = null;
	
	/*
	 * Method Name: addUser
	 * Author: Jayesh Bolke
	 * Date: 22nd September 2017
	 * Description: AddUser accepts user Object and inserts
	 * user details into database. user Id is generated using
	 * sequence. addUser also throws GameException
	 */
	
	
	@Override
	public int addUser(UserBean user) throws GameException {
		
		int userId=0;
		
		try(Connection con=DbConnection.getConnection())
		{
			//get user details
			
			String userName  = user.getUserName();
			String address   = user.getAddress();
			float cardAmt    = user.getCardAmt();
			
			//getsequence number assign to userId
			
			preparedStatement = con.prepareStatement(IQueryMapper.userid);
			res = preparedStatement.executeQuery();
			
			
			if(res.next()==false)
			{
				throw new GameException("Could not add User. UserId Generation failed.");
			}
			
			userId=res.getInt(1);
		
			//insert into database table users
			
			preparedStatement =con.prepareStatement(IQueryMapper.adduser);
			
			preparedStatement.setInt(1, userId);
			preparedStatement.setString(2, userName);
			preparedStatement.setString(3, address);
			preparedStatement.setFloat(4, cardAmt);
			
			
			preparedStatement.execute();
		}
		catch(Exception e)
		{
			throw new GameException(e.getMessage());
		}
		
		return userId;
	}
	
	/*
	 * Method Name: showGameList
	 * Author: Jayesh Bolke
	 * Date: 22nd September 2017
	 * Description: showGameList fetch game details from database. 
	 * ShowGameList also throws GameException
	 */
	
	
	@Override
	public List<GameBean> showGameList() throws GameException {

		List<GameBean> list=new ArrayList<GameBean>();
		GameBean bean = new GameBean();
		
		try(Connection con=DbConnection.getConnection())
		{	
			//get games list
			
			preparedStatement = con.prepareStatement(IQueryMapper.showgames);
			res = preparedStatement.executeQuery();
			
			//check for null records
			
			if(res.next()==false)
			{
				throw new GameException("No R3cords found.");
			}
			else
			{
				do
				{
					
				bean.setGameName(res.getString("name"));
				bean.setGameAmt(res.getFloat("amount"));
				list.add(bean);
				bean= new GameBean();
				
				}while(res.next());
			}
			
			
		}
		catch(Exception e)
		{
			throw new GameException(e.getMessage());
		}
		
		
		return list;
	}

}
