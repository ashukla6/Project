package com.cg.gc.service;

import java.util.List;

import com.cg.gc.bean.GameBean;
import com.cg.gc.bean.UserBean;
import com.cg.gc.exception.GameException;

public interface IGameCityService {
	
	public int addUser(UserBean user) throws GameException;
	public List<GameBean> showGameList() throws GameException;
}
