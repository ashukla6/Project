package com.cg.gc.service;

import java.util.List;

import com.cg.gc.bean.GameBean;
import com.cg.gc.bean.UserBean;
import com.cg.gc.dao.GameCityDAOImpl;
import com.cg.gc.dao.IGameCityDAO;
import com.cg.gc.exception.GameException;

public class GameCityServiceImpl implements IGameCityService {
	
	IGameCityDAO gameCityDAO;
	
	
	
	public GameCityServiceImpl() {

		gameCityDAO=new GameCityDAOImpl();
	}

	@Override
	public int addUser(UserBean user) throws GameException {
		// TODO Auto-generated method stub
		return gameCityDAO.addUser(user);
	}

	@Override
	public List<GameBean> showGameList() throws GameException {
		// TODO Auto-generated method stub
		return gameCityDAO.showGameList();
	}

}
