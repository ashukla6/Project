package com.cg.web.service;

import com.cg.web.dto.ComplainBean;
import com.cg.web.exception.ComplainException;

public interface IComplaintService {
	public int raiseComplaint(ComplainBean complaint ) throws ComplainException;
	public ComplainBean getComplaint(int complaintid) throws ComplainException;
	

}
