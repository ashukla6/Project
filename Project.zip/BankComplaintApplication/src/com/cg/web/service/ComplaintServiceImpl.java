package com.cg.web.service;

import com.cg.web.dao.ComplaintDaoImpl;
import com.cg.web.dao.IComplaintDao;
import com.cg.web.dto.ComplainBean;
import com.cg.web.exception.ComplainException;

public class ComplaintServiceImpl implements IComplaintService {
	
	private IComplaintDao complainDao;
	public ComplaintServiceImpl()
	{
		complainDao =new ComplaintDaoImpl();
	}

	@Override
	public int raiseComplaint(ComplainBean complaint) throws ComplainException {
		// TODO Auto-generated method stub
		
		int complainid=0;
		complainid=complainDao.raiseComplaint(complaint);
		return complainid;
	}

	@Override
	public ComplainBean getComplaint(int complaintid) throws ComplainException {
		// TODO Auto-generated method stub
		ComplainBean complaint=null;
		complaint=complainDao.getComplaint(complaintid);
		
		return complaint;
	}

}
