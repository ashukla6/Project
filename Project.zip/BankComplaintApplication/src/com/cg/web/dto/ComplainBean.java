package com.cg.web.dto;

import java.sql.Date;

public class ComplainBean {
	public ComplainBean(int id, String customerName, int accountId,
			String category, Date complaintDate, String description,
			String priority, String status) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.accountId = accountId;
		this.category = category;
		this.complaintDate = complaintDate;
		this.description = description;
		this.priority = priority;
		this.status = status;
	}
	private int id ;
	public ComplainBean(String customerName, int accountId, String category,
			String description) {
		super();
		this.customerName = customerName;
		this.accountId = accountId;
		this.category = category;
		this.description = description;
	}
	private String customerName ;
	private int accountId ;
	private String category ;
	private Date complaintDate  ;
	private String description  ;
	private String priority ;
	private String status ;
	
	public ComplainBean() {
		super();
	}

	@Override
	public String toString() {
		return "ComplainBean [id=" + id + ", customerName=" + customerName
				+ ", accountId=" + accountId + ", category=" + category
				+ ", complaintDate=" + complaintDate + ", description="
				+ description + ", priority=" + priority + ", status=" + status
				+ "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Date getComplaintDate() {
		return complaintDate;
	}

	public void setComplaintDate(java.util.Date date) {
		this.complaintDate = (Date) date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	

}
