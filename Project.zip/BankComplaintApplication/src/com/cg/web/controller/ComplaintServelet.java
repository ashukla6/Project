package com.cg.web.controller;

import java.io.IOException;


import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.web.dto.ComplainBean;
import com.cg.web.exception.ComplainException;
import com.cg.web.service.ComplaintServiceImpl;
import com.cg.web.service.IComplaintService;

interface Categories
{
	String InternetBanking="Internet Banking";
	String BasicBanking="Basic Banking";
	String Others="Others";
}

@WebServlet("/ComplaintServelet")
public class ComplaintServelet extends HttpServlet implements Categories{
	private static final long serialVersionUID = 1L;
	
	private IComplaintService complaintservice;
	
       
   
    public ComplaintServelet() {
        super();
        // TODO Auto-generated constructor stub
    
    complaintservice=new ComplaintServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request,response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request,response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		String action=request.getParameter("action");
		switch(action)
		{
		case "addcomplaint":
			
			String custName=request.getParameter("customername");
			String accId=request.getParameter("accountId");
			String cat=request.getParameter("category");
			String desc=request.getParameter("description");
			ComplainBean complainbean =new ComplainBean();
			
			complainbean.setCustomerName(custName);
			complainbean.setAccountId(Integer.parseInt(accId));
			complainbean.setCategory(cat);
			complainbean.setDescription(desc);
			switch (cat)
			{
			case InternetBanking:complainbean.setPriority("High");
			case BasicBanking:complainbean.setPriority("Medium");
			case Others:complainbean.setPriority("low");
			
			}
			
			complainbean.setComplaintDate(new Date());
			complainbean.setStatus("Open");
			
			
			RequestDispatcher rd=null;
			
			try
			{
				int complainid =complaintservice.raiseComplaint(complainbean);
				request.setAttribute("compId",complainid);
				rd=request.getRequestDispatcher("raisecomplaint.jsp");
				
			}
			catch(ComplainException e)
			{
				request.setAttribute("errmsg", "something went wrong");
				
			}
		}
	}

}
