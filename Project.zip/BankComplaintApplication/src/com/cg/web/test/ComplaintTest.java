package com.cg.web.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.Month;

import org.junit.Test;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.exception.TruckException;
import com.cg.web.dao.ComplaintDaoImpl;
import com.cg.web.dao.IComplaintDao;
import com.cg.web.dto.ComplainBean;

public class ComplaintTest {
	IComplaintDao check=new ComplaintDaoImpl();

	@Test
	public void test() {
		ComplainBean cust=new ComplainBean();
		cust.setCustomerName("Abhishek");
		cust.setAccountId(1000);
		cust.setCategory("others");
		cust.setComplaintDate("2017-05-22");
		cust.setDescription("asdfgjekhfjl");
		cust.setPriority("High");
		cust.setStatus("open");
		
		try
		{
			int bookingid=check.bookingid();
			assertEquals(5006,bookingid);
		}
		catch(TruckException e)
		{
			fail(e.getMessage());
		}
		fail("Not yet implemented");
	}

}
