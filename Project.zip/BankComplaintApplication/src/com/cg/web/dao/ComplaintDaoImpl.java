package com.cg.web.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.web.dto.ComplainBean;
import com.cg.web.exception.ComplainException;
import com.cg.web.util.DBUtil;

public class ComplaintDaoImpl implements IComplaintDao {
	public int generateComplaintId() throws ComplainException, SQLException
	{
		int complaintid=0;
		ResultSet res=null;
		try(Connection con=DBUtil.getConnection())
		{
			Statement stm=con.createStatement();
			res=stm.executeQuery("select complaintid_seq.nextVal from dual");
			if(res.next() != true)
			{
				throw new ComplainException("could not generate complaint id");
			}
			complaintid=res.getInt(1);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new ComplainException(e);
		}
		finally
		{
			res.close();
		}
		return complaintid;
		
	}

	@Override
	public int raiseComplaint(ComplainBean complaint) throws ComplainException {
		// TODO Auto-generated method stub
		
		int complaintid=0;
		try(Connection con=DBUtil.getConnection())
		{
			complaintid=generateComplaintId();
			complaint.setId(complaintid);
			PreparedStatement pstm=con.prepareStatement("inset into Complaint values(?,?,?,?,?,?,?,?)");
			pstm.setInt(1, complaint.getId());
			pstm.setString(2, complaint.getCustomerName());
			pstm.setInt(3, complaint.getAccountId());
			pstm.setString(4, complaint.getCategory());
			pstm.setDate(5, new java.sql.Date(complaint.getComplaintDate().getTime()));
			pstm.setString(6, complaint.getDescription());
			pstm.setString(7, complaint.getPriority());
			pstm.setString(8, complaint.getStatus());
			pstm.execute();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new ComplainException(e);
		}
		return complaintid;
	}

	@Override
	public ComplainBean getComplaint(int complaintid) throws ComplainException {
		// TODO Auto-generated method stub
		ComplainBean Complaint=null;
		try(Connection con=DBUtil.getConnection())
		{
			
			PreparedStatement pstm=con.prepareStatement("select * from complaint where id=?");
			pstm.setInt(1, complaintid);
			ResultSet res=pstm.executeQuery();
			if(res.next() !=true )
				throw new ComplainException("no complaintwith complaintId"+complaintid);
			
			Complaint=new ComplainBean();
			Complaint.setId(res.getInt(1));
			Complaint.setCustomerName(res.getString(2));
			Complaint.setAccountId(res.getInt(3));
			Complaint.setCategory(res.getString(4));
			Complaint.setComplaintDate(res.getDate(5));
			Complaint.setDescription(res.getString(6));
			Complaint.setPriority(res.getString(7));
			Complaint.setStatus(res.getString(8));
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new ComplainException(e);
		}
		return Complaint;
	}

}
