package com.cg.web.dao;

import com.cg.web.dto.ComplainBean;
import com.cg.web.exception.ComplainException;

public interface IComplaintDao {
	public int raiseComplaint(ComplainBean complaint ) throws ComplainException;
	public ComplainBean getComplaint(int complaintid) throws ComplainException;
	

}
