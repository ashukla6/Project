drop table Complaint cascade constraint;

create table Complaint (
id number(8),
customerName  varchar2(20),
accountId number(8) ,
category varchar2(20),
complaintDate date ,
description varchar2(300) ,
priority varchar2(10),
status varchar2(10),
primary key (id)
);

create sequence complaintId_seq start with 1000;