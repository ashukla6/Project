package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.TakeCareClinicException;

public interface IPatientService {

	public int addPatientDetails(PatientBean patient)throws TakeCareClinicException;
	public PatientBean getPatientDetails(int patientId)throws TakeCareClinicException;
}
