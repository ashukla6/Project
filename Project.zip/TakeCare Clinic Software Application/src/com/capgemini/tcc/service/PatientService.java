package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.TakeCareClinicException;

public class PatientService implements IPatientService {
	
	
IPatientDAO dao;
	
	public PatientService() {
		// TODO Auto-generated constructor stub
		dao =new PatientDAO();
	}
	

	public IPatientDAO getDao() {
		return dao;
	}



	public void setDao(IPatientDAO dao) {
		this.dao = dao;
	}
	
	static String namePattern = "[A-Z]{1}[a-z]{2,}";		//name format pattern
	static String contactPattern = "[0-9]{10}";				//phone no format pattern


	@Override
	public int addPatientDetails(PatientBean patient) throws TakeCareClinicException {
		// TODO Auto-generated method stub
		return dao.addPatientDetails(patient);
	}


	@Override
	public PatientBean getPatientDetails(int patientId)
			throws TakeCareClinicException {
		// TODO Auto-generated method stub
		return dao.getPatientDetails(patientId);
	}

	
	//validating input name format
	public static boolean validateName(String name)
	{
		boolean flag = false;
		if(name.matches(namePattern))
		{
			flag = true;
		}
		
		return flag;
	}
	
	//validating age
	public static boolean validateAge(int Age)
	{
		boolean flag = false;
		if(Age<=110)
		{
			flag = true;
		}
		return flag;
	}
	
	//validating input phone number format
	public static boolean validateContact(String contact)
	{
		boolean flag = false;
		if(contact.matches(contactPattern))
		{
			flag = true;
		}
		return flag;
	}

	
}
