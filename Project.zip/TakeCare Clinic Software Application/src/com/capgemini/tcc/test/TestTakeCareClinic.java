package com.capgemini.tcc.test;

import java.time.LocalDate;
import java.time.Month;

import org.junit.Test;

import static org.junit.Assert.*;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.TakeCareClinicException;

public class TestTakeCareClinic {
	
	IPatientDAO dao = new PatientDAO();
	
	
	@Test			//Test to Pass 
	public void testAddDetailsPass() 
	{
		PatientBean patient = new PatientBean();
		patient.setPatient_name("Robb");
		patient.setAge(20);
		patient.setPhone("1234567890");
		patient.setDescription("Cough");
		patient.setConsultation_date(LocalDate.of(2016, Month.SEPTEMBER,20));
		
		int patientId;
		try 
		{
			patientId = dao.addPatientDetails(patient);
			assertEquals(1004, patientId);			//add Next Value of sequence
		} 
		catch (TakeCareClinicException e) 
		{
			// TODO Auto-generated catch block
			fail(e.getMessage());
		}
		
		
	}
	
	@Test			//Test to Fail
	public void testAddDetailsFail() 
	{
		PatientBean patient = new PatientBean();
		patient.setPatient_name("Ronny");
		patient.setAge(25);
		patient.setPhone("9876543210");
		patient.setDescription("Fever");
		patient.setConsultation_date(LocalDate.of(2016, Month.SEPTEMBER,20));
		
		
		int patientId;
		try 
		{
			patientId = dao.addPatientDetails(patient);
			assertEquals(0, patientId);					//Patient Id is  always generated. So test will fail!
		} 
		catch (TakeCareClinicException e) 
		{
			// TODO Auto-generated catch block
			fail(e.getMessage());
		}
	}
	
	// Test to pass. Will expect a Exception on unavailable Patient ID.
		@Test(expected = TakeCareClinicException.class)
		public void testGetEnquiryDetailsPass() 
		{
			PatientBean patient = new PatientBean();
			try {
				patient = dao.getPatientDetails(1101);
				assertNotNull(patient);
			} catch (TakeCareClinicException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//Test to fail. Will expect a Exception on unavailable Patient ID. But Id exists. So test fails
		@Test(expected = TakeCareClinicException.class)
		public void testGetEnquiryDetailsFail()  {
			PatientBean patient = new PatientBean();
			try {
				patient = dao.getPatientDetails(1000);
				assertNotNull(patient);
			} catch (TakeCareClinicException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

}
