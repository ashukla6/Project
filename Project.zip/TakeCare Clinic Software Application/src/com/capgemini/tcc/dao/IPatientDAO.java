package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.TakeCareClinicException;

public interface IPatientDAO {

	public int addPatientDetails(PatientBean patient)throws TakeCareClinicException;
	public PatientBean getPatientDetails(int patientId)throws TakeCareClinicException;
}
