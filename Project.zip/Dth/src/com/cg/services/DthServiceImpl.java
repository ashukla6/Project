package com.cg.services;

import java.util.List;

import com.cg.daos.DthDao;
import com.cg.daos.DthDaoImpl;
import com.cg.dto.DthBean;
import com.cg.exception.DthException;

public class DthServiceImpl implements DthServices {
	public DthDao dao=null;

	public DthServiceImpl() {
		// TODO Auto-generated constructor stub
		
		dao=new DthDaoImpl();
	}

	@Override
	public DthBean getDetails(long phoneno) throws DthException {
		// TODO Auto-generated method stub
		return dao.getDetails(phoneno);
	}

	@Override
	public float recommended(float account, String packageId)
			throws DthException {
		// TODO Auto-generated method stub
		return dao.recommended(account, packageId);
	}

	@Override
	public boolean updateDate(float account, long phoneno) throws DthException {
		// TODO Auto-generated method stub
		return dao.updateDate(account, phoneno);
	}

}
