package com.cg.services;

import java.util.List;

import com.cg.dto.DthBean;
import com.cg.exception.DthException;

public interface DthServices {
	public DthBean getDetails(long phoneno) throws DthException;
	public float recommended(float account,String packageId) throws DthException;
	public boolean updateDate(float account,long phoneno) throws DthException;

}
