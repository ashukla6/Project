package com.cg.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




import com.cg.dto.DthBean;
import com.cg.exception.DthException;
import com.cg.util.DbConnection;


public class DthDaoImpl implements DthDao {

	public DthDaoImpl() {
		// TODO Auto-generated constructor stub
		System.out.println("In dao constructor");
	}
	DthBean bean=null;
	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;
	@Override
	public DthBean getDetails(long phoneno) throws DthException {
		// TODO Auto-generated method stub
		
		bean=new DthBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.VIEW);
			preparedStatement.setLong(1, phoneno);
			System.out.println("in dao");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				bean.setSubscriberId(resultSet.getInt(1));
				
				bean.setMobileNo(resultSet.getLong(2));
				bean.setPackageId(resultSet.getString(3));
				bean.setAccountBalance(resultSet.getFloat(4));
				
				
				System.out.println(bean);
				
				
			
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new DthException("Problem in performing connection");
		}
		
		
		
		
		return bean;
	}
	@Override
	public float recommended(float account,String packageId) throws DthException {
		// TODO Auto-generated method stub
		float recommend=0;
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.Amount);
			preparedStatement.setString(1,packageId );
			System.out.println("in dao");
			resultSet = preparedStatement.executeQuery();
			float amount=0;
			while (resultSet.next())
			{
			 amount=resultSet.getFloat(1);
			System.out.println(amount);
			System.out.println(account);
			}
			recommend= amount-account;
			System.out.println(recommend);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return recommend;
	}
	@Override
	public boolean updateDate(float account, long phoneno) throws DthException {
		// TODO Auto-generated method stub
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.UPDATE);
			preparedStatement.setFloat(1,account );
			preparedStatement.setLong(2, phoneno);
			System.out.println("in dao");
			int resultSet = preparedStatement.executeUpdate();
			if(resultSet >0)
			{
				return true;
			}
			else
			return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return false;
		}
		
		
	}
	
}
