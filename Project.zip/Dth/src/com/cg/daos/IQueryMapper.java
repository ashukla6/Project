package com.cg.daos;

public interface IQueryMapper {
	String VIEW = "SELECT subscriber_id,mobile_number,package_id,account_balance FROM subscriber_account_details WHERE mobile_number=?";
	String Amount="SELECT package_amount FROM datasky_packages WHERE package_id=?";
	String UPDATE ="UPDATE subscriber_account_details SET account_balance=account_balance-?,rechargedate=sysdate+30 WHERE mobile_number=?";
}
