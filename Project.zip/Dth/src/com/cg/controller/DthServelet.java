package com.cg.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.DthBean;
import com.cg.exception.DthException;
import com.cg.services.DthServiceImpl;
import com.cg.services.DthServices;


@WebServlet("*.do")
public class DthServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DthServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		DthServices service=null;
		String target="";
		DthBean bean=null;
		float recommend=0;
		String packageId=null;
		float account=0;
		HttpSession session = request.getSession(true);
		String path = request.getServletPath().trim();
		switch (path)
		{
		case "/check.do":
		{
			String phonen= request.getParameter("mobileno") ;
			System.out.println(phonen);
			session.setAttribute("phoneno", phonen);
			
			long phoneno=Long.parseLong(phonen);
			bean=new DthBean();
			
			service=new DthServiceImpl();
			
			try {
				bean=service.getDetails(phoneno);
				packageId=bean.getPackageId();
				account=bean.getAccountBalance();
				System.out.println(account);
				System.out.println(packageId);
				
				System.out.println(bean);
				recommend=service.recommended(account, packageId);
				System.out.println(recommend);
				LocalDate date=LocalDate.now();
				session.setAttribute("date", date);
				
			
			
			} catch (DthException e) {
				session.setAttribute("error", e.getMessage());
				target = "error.jsp";
			}
			if (bean.getSubscriberId() != 0) {
				//session.setAttribute("error", null);
				session.setAttribute("details",bean);
				session.setAttribute("recommend", recommend);
				target = "recharge.jsp";
				} else {
				session.setAttribute("consumer", null);
				session.setAttribute("error",
						"Sorry No data Found for given ID!");
				target = "error.jsp";
			}	
			
		break;	
			
			
			
			
		}//case
		case "/register.do":
		{
			float rechargevalue= Float.parseFloat(request.getParameter("rechargevalue")) ;
			System.out.println(rechargevalue);
			if(rechargevalue>100)
			{
				
			
			String phoneno= (String)session.getAttribute("phoneno");
			long phoni=Long.parseLong(phoneno);
			System.out.println(phoni);
			boolean flag=true;
			
			bean=new DthBean();
			
			service=new DthServiceImpl();
			
			try {
				flag=service.updateDate(rechargevalue, phoni);
				System.out.println(flag);
				
			
			
			} catch (DthException e) {
				session.setAttribute("error", e.getMessage());
				target = "error.jsp";
			}
			if (flag==true) {
				//session.setAttribute("error", null);
				
				target = "success.jsp";
				} else {
				session.setAttribute("consumer", null);
				session.setAttribute("error",
						"Update could not be succesful");
				target = "error.jsp";
			}
			}
			else
			{
				session.setAttribute("error", "Error!! Amount is less than 100");
				target = "error.jsp";
			
			}
			
		break;	
			
			
			
			
		}//case
		}//switch
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
		
		
		
	}

}//servelet
