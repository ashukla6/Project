package com.cg.dto;

import java.time.LocalDate;

public class DthBean {
	private int subscriberId;
	public int getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(int subscriberId) {
		this.subscriberId = subscriberId;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPackageId() {
		return packageId;
	}
	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}
	public DthBean() {
		super();
	}
	public DthBean(int subscriberId, long mobileNo, String packageId,
			float accountBalance) {
		super();
		this.subscriberId = subscriberId;
		this.mobileNo = mobileNo;
		this.packageId = packageId;
		this.accountBalance = accountBalance;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public LocalDate getRechargedate() {
		return rechargedate;
	}
	public void setRechargedate(LocalDate rechargedate) {
		this.rechargedate = rechargedate;
	}
	private long mobileNo;
	private String packageId;
	private float accountBalance;
	private LocalDate rechargedate;
}
