/**
 * 
 */

function validateForm()
{
	var totalRuns = document.PlayerForm.runs.value;
	var NoOfCenturies = document.PlayerForm.centuries.value;
	
	runs = parseInt(totalRuns);
	centuries = parseInt(NoOfCenturies);
	
	if(runs>(centuries*100))
		return true;
	else
	{
		alert("Total run score cannot be less than no. of centures * 100");
		return false;
	}
}