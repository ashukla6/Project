package com.cg.cs.exception;

public class CricketScoreException extends Exception{
	
	String message;

	public CricketScoreException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CricketScoreException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CricketScoreException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CricketScoreException(String message) {
		super();
		this.message = message;
		// TODO Auto-generated constructor stub
	}

	public CricketScoreException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return this.message;
	}
	
	

}
