package com.cg.cs.dto;

import java.sql.Date;

public class CricketScoreDTO {
	
	private int playerId;
	private String playerName;
	private Date playerDob ;
	private String playerCountry;
	private String playerBattingStyle;
	private int playerCenturies;
	private int playerMatches;
	private int playerRuns;
//	private int playerAge;
	
	
	public CricketScoreDTO() {
		super();
	}
	
	//without flatId
	public CricketScoreDTO(String playerName, Date playerDob,
			String playerCountry, String playerBattingStyle,
			int playerCenturies, int playerMatches, int playerRuns) {
		super();
		this.playerName = playerName;
		this.playerDob = playerDob;
		this.playerCountry = playerCountry;
		this.playerBattingStyle = playerBattingStyle;
		this.playerCenturies = playerCenturies;
		this.playerMatches = playerMatches;
		this.playerRuns = playerRuns;
	}

	//with flatId
	public CricketScoreDTO(int playerId, String playerName, Date playerDob,
			String playerCountry, String playerBattingStyle,
			int playerCenturies, int playerMatches, int playerRuns) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.playerDob = playerDob;
		this.playerCountry = playerCountry;
		this.playerBattingStyle = playerBattingStyle;
		this.playerCenturies = playerCenturies;
		this.playerMatches = playerMatches;
		this.playerRuns = playerRuns;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public Date getPlayerDob() {
		return playerDob;
	}

	public void setPlayerDob(Date playerDob) {
		this.playerDob = playerDob;
	}

	public String getPlayerCountry() {
		return playerCountry;
	}

	public void setPlayerCountry(String playerCountry) {
		this.playerCountry = playerCountry;
	}

	public String getPlayerBattingStyle() {
		return playerBattingStyle;
	}

	public void setPlayerBattingStyle(String playerBattingStyle) {
		this.playerBattingStyle = playerBattingStyle;
	}

	public int getPlayerCenturies() {
		return playerCenturies;
	}

	public void setPlayerCenturies(int playerCenturies) {
		this.playerCenturies = playerCenturies;
	}

	public int getPlayerMatches() {
		return playerMatches;
	}

	public void setPlayerMatches(int playerMatches) {
		this.playerMatches = playerMatches;
	}

	public int getPlayerRuns() {
		return playerRuns;
	}

	public void setPlayerRuns(int playerRuns) {
		this.playerRuns = playerRuns;
	}

	@Override
	public String toString() {
		return "CricketScoreDTO [playerId=" + playerId + ", playerName="
				+ playerName + ", playerDob=" + playerDob + ", playerCountry="
				+ playerCountry + ", playerBattingStyle=" + playerBattingStyle
				+ ", playerCenturies=" + playerCenturies + ", playerMatches="
				+ playerMatches + ", playerRuns=" + playerRuns + "]";
	}

		

}
