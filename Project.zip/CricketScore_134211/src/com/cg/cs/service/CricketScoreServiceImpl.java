package com.cg.cs.service;

import java.util.ArrayList;

import com.cg.cs.dao.CricketScoreDAOImpl;
import com.cg.cs.dao.ICricketScoreDAO;
import com.cg.cs.dto.CricketScoreDTO;
import com.cg.cs.exception.CricketScoreException;

public class CricketScoreServiceImpl implements ICricketScoreService{
	
	ICricketScoreDAO dao;
	
	public CricketScoreServiceImpl() {
		dao = new CricketScoreDAOImpl();
	}

	@Override
	public CricketScoreDTO registerPlayer(CricketScoreDTO player)
			throws CricketScoreException {
		// TODO Auto-generated method stub
		return dao.registerPlayer(player);
	}

	@Override
	public ArrayList<CricketScoreDTO> viewAllPlayers()
			throws CricketScoreException {
		// TODO Auto-generated method stub
		return dao.viewAllPlayers();
	}

	@Override
	public int getPlayerAge(int playerId) throws CricketScoreException {
		// TODO Auto-generated method stub
		return dao.getPlayerAge(playerId);
	}

	
	

}
