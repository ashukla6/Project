package com.cg.cs.service;

import java.util.ArrayList;

import com.cg.cs.dto.CricketScoreDTO;
import com.cg.cs.exception.CricketScoreException;

public interface ICricketScoreService {

	public CricketScoreDTO registerPlayer(CricketScoreDTO player) throws CricketScoreException;
//	ArrayList<Integer> getAllPlayers() throws CricketScoreException;
	public ArrayList<CricketScoreDTO> viewAllPlayers() throws CricketScoreException;
	public int getPlayerAge(int playerId) throws CricketScoreException;
}
