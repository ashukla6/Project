package com.cg.cs.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.cg.cs.dto.CricketScoreDTO;
import com.cg.cs.exception.CricketScoreException;
import com.cg.cs.service.CricketScoreServiceImpl;
import com.cg.cs.service.ICricketScoreService;

/*
 * 
 * DataSource is 
 * "java:/jdbc/Server1"
 * 
 * dataSource = (DataSource)context.lookup("java:/jdbc/Server1");
 * 
 * */


@WebServlet("/RegistrationServlet")	//url pattern
public class RegistrationServlet extends HttpServlet {

    public RegistrationServlet() {
     
    	System.out.println("Servlet object created ");
    	
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		System.out.println("within doGet() ");
		String action = request.getParameter("action");
		System.out.println("32 " + action + " 3532");
		ICricketScoreService css = new CricketScoreServiceImpl();
		CricketScoreDTO player = null;
		int id = 0; 
		
		
		switch(action)
		{
		
			case "newPlayer":
			{
				RequestDispatcher dispatcher = request.getRequestDispatcher("NewPlayer.jsp");
				dispatcher.forward(request, response);
				break;
			}
		
			case "viewPlayers":
			{
				try {
					ArrayList<CricketScoreDTO> playerList = css.viewAllPlayers();
					ArrayList<Integer> playerAgeList = new ArrayList<Integer>();
					int age = -2;
					int playerId = -3;
					for(CricketScoreDTO player1 : playerList)
					{
						playerId = player1.getPlayerId();
						age = css.getPlayerAge(playerId);
						System.out.println(age + " " + player1);
						playerAgeList.add(age);
					}
//					Map<CricketScoreDTO,Integer> combo = new HashMap<CricketScoreDTO,Integer>(); 
					
					HttpSession session = request.getSession();
					session.setAttribute("ages", playerAgeList);
					
					request.setAttribute("playersTable", playerList);
					request.setAttribute("playersAge", playerAgeList);
					
				} catch (CricketScoreException e) {
					String errorMessage = e.getMessage();
					request.setAttribute("pmcexception", errorMessage);
					RequestDispatcher dispatcher = request.getRequestDispatcher("errorpage.jsp");
					dispatcher.forward(request,response);
				}
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("ViewPlayers.jsp");
				dispatcher.forward(request,response);
				break;
			}		
		
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		//what should be written here 
		//Retrieve values entered in the html page 
		System.out.println("within doPost() ");
		String action = request.getParameter("action");
		ICricketScoreService ccs = new CricketScoreServiceImpl();
		
		RequestDispatcher dispatcher;
		CricketScoreDTO player;
		
		switch(action)
		{
		
			case "registerPlayer":
			{
				player = new CricketScoreDTO();
				player.setPlayerName(request.getParameter("pName"));
				String dateStr = request.getParameter("dob");
				Date date = Date.valueOf(dateStr);
				player.setPlayerDob(date);
				player.setPlayerCountry(request.getParameter("country"));
				player.setPlayerBattingStyle(request.getParameter("type"));
				Integer centuries = Integer.valueOf(request.getParameter("centuries"));
				player.setPlayerCenturies(centuries);
				Integer matches = Integer.valueOf(request.getParameter("matches"));
				player.setPlayerMatches(matches);
				Integer runs = Integer.valueOf(request.getParameter("runs"));
				player.setPlayerRuns(runs);
				
				System.out.println(player);
				
				CricketScoreDTO temp;
				try {
					temp = ccs.registerPlayer(player);
					System.out.println("player id is " + temp.getPlayerId());
					int playerId = temp.getPlayerId();
					request.setAttribute("playerId", playerId);
					System.out.println(temp);
				} catch (CricketScoreException e) {
					String errorMessage = e.getMessage();
					request.setAttribute("pmcexception", errorMessage);
					dispatcher = request.getRequestDispatcher("errorpage.jsp");
					dispatcher.forward(request,response);
				}
				
				
				dispatcher = request.getRequestDispatcher("InsertSuccess.jsp");
				dispatcher.forward(request,response);
				break;
				
			}
			
		
			
//			catch(CricketScoreException e)
//			{
//				System.out.println("Error while doing this " + e.getMessage());
//				String errorMessage = e.getMessage();
//				request.setAttribute("flatexception", errorMessage);
//				RequestDispatcher dispatcherFlat = request.getRequestDispatcher("flatDetailsError.jsp");
//				dispatcherFlat.forward(request,response);
//			
//			}
//			
//			dispatcher = request.getRequestDispatcher("success.jsp");
//			
//			dispatcher.forward(request,response);
//			break;
			}
		
	}

}
