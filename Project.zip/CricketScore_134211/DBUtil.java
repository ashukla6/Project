package com.cg.frs.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	
	public static Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Connection con = null;
		
		String path = "P:/New folder/MyProject/database.properties";
		InputStream propsFile = null;		
		Properties dbProperties = new Properties();
		
		try
		{
			propsFile = new FileInputStream(path);
			dbProperties.load(propsFile);
			propsFile.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		//Loads and Registers Oracle Driver
		Class.forName(dbProperties.getProperty("driver"));

		//Acquire Database connection
		con = DriverManager.getConnection(
				dbProperties.getProperty("url"),
				dbProperties.getProperty("username"),
				dbProperties.getProperty("password"));
		
		return con;
		
	}

}
