CREATE TABLE cricket_score(
player_id NUMBER primary key, 
player_name varchar2(40),
dob DATE, 
country varchar2(40), 
batting_style varchar2(20),
centuries number, 
matches number , 
total_run_score number );

CREATE SEQUENCE player_seq;


INSERT into cricket_score VALUES(player_seq.NEXTVAL,'Sachin Tendulkar','04/24/1973','India','Right Handed Batsman',49,463,18426);

INSERT into cricket_score VALUES(player_seq.NEXTVAL,'R.T Pointing','12/19/1974','Australia','Left Handed Batsman',30,375,13704);

INSERT into cricket_score VALUES(player_seq.NEXTVAL,'S. T Jayasuriya','06/30/1969','Shrilanka','Right Handed Batsman',28,445,13480);

INSERT into cricket_score VALUES(player_seq.NEXTVAL,'S. C Ganguly','07/08/1972','India','Left Handed Batsman',22,311,11363);




