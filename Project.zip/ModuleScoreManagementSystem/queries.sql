CREATE table trainees(trainee_id number primary key, trainee_name varchar2(30));

INSERT into trainees values(898983,'Tina');
INSERT into trainees values(898984,'Vina');
INSERT into trainees values(898985,'Gita');
INSERT into trainees values(898986,'Rita');
INSERT into trainees values(898987,'Sita');
INSERT into trainees values(898988,'Mala');

CREATE table AssessmentScore(trainee_id number references trainees(trainee_id), module_name varchar2(10), mpt number, mtt number, ass_marks number, total number, grade number);