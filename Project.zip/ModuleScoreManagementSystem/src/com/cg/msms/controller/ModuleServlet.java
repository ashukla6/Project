package com.cg.msms.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.msms.bean.AssessmentBean;
import com.cg.msms.exception.ModuleException;
import com.cg.msms.service.IModuleService;
import com.cg.msms.service.ModuleService;



@WebServlet("/ModuleServlet")
public class ModuleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    IModuleService service;
    AssessmentBean aBean;
    public ModuleServlet() {
    	service = new ModuleService();
    	
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		ArrayList<Integer> list = new ArrayList<>();
		HttpSession session = request.getSession();
		
switch(action){
		
		case "add":
			 		
			try {
				list= service.getId();
				System.out.println("Inside Try");
				System.out.println(list);
				session.setAttribute("traineeId", list);
			} catch (ModuleException e) 
				{
				String message= "Sorry, something went wrong. Try again";
				request.setAttribute("Message", message);
				RequestDispatcher dispatcher = 
						request.getRequestDispatcher("error.jsp");
						
						dispatcher.forward(request,response);
				}
			System.out.println("Above Add page");
			RequestDispatcher dispatcher = 
			request.getRequestDispatcher("add.jsp");
			
			dispatcher.forward(request,response);
			
			break;
			
		case "DirectHome":
			
		RequestDispatcher dispatcher1 = 
				request.getRequestDispatcher("index.jsp");
				
				dispatcher1.forward(request,response);
				
				break;
		
}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		String action= request.getParameter("action");
		boolean flag= false;
		boolean checkEntry = false;
		
		switch(action)
		{
		case "addDetails":
			int id = Integer.parseInt(request.getParameter("TraineeId"));
			String Mname = request.getParameter("mName");
			int Mpt = Integer.parseInt(request.getParameter("mpt"));
			int Mtt = Integer.parseInt(request.getParameter("mtt"));
			int assignment = Integer.parseInt(request.getParameter("assig"));
			
			try {
				checkEntry= service.Check(id, Mname);
			} catch (ModuleException e1) {
				
				String message= "Sorry, something went wrong. Try again";
				request.setAttribute("Message", message);
				RequestDispatcher dispatcher = 
						request.getRequestDispatcher("error.jsp");
						
						dispatcher.forward(request,response);
				
			}
			
			
			if(checkEntry== false)
			{
			
			aBean = new AssessmentBean(id, Mname, Mpt, Mtt, assignment);
			try {
				flag = service.addDetails(aBean);
				System.out.println(flag);
			} catch (ModuleException e) {
				String message= "Sorry, something went wrong. Try again";
				request.setAttribute("Message", message);
				RequestDispatcher dispatcher = 
						request.getRequestDispatcher("error.jsp");
						
						dispatcher.forward(request,response);
			}
			
			if(flag==true)
			{	int grade=0;
				double total = Mpt*(0.7) + (.15*Mtt) + (0.15)*assignment;
				try {
					grade = service.getGrade(total);
				} catch (ModuleException e) {
					String message= "Sorry, something went wrong. Try again";
					request.setAttribute("Message", message);
					RequestDispatcher dispatcher = 
							request.getRequestDispatcher("error.jsp");
							
							dispatcher.forward(request,response);
					
					
				}
					request.setAttribute("grade", grade);
					request.setAttribute("Total", total);
					request.setAttribute("Id", id);
					request.setAttribute("Mname", Mname);
				RequestDispatcher dispatcher = 
						request.getRequestDispatcher("ModuleScore.jsp");
						dispatcher.forward(request,response);
			}
		
		}
			else if(checkEntry==true)
			{	
				String str1= "Sorry, Details cannot be entered as module score Of entered trainee already exist in table";
				request.setAttribute("EntryError", str1);
				RequestDispatcher dispatcher = 
						request.getRequestDispatcher("add.jsp");
						dispatcher.forward(request,response);
			}
		}
		
	}

}
