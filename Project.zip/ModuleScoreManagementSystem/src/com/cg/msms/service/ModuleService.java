package com.cg.msms.service;

import java.util.ArrayList;

import com.cg.msms.bean.AssessmentBean;
import com.cg.msms.dao.IModuleDao;
import com.cg.msms.dao.ModuleDao;
import com.cg.msms.exception.ModuleException;

public class ModuleService implements IModuleService {
	
	IModuleDao dao;
	
	public ModuleService() {
		dao= new ModuleDao();
		
	}

	@Override
	public ArrayList<Integer> getId() throws ModuleException {
		
		return dao.getId();
	}

	@Override
	public boolean addDetails(AssessmentBean bean) throws ModuleException {
	
		return dao.addDetails(bean);
	}

	@Override
	public int getGrade(double total) throws ModuleException {
		
		return dao.getGrade(total);
	}

	@Override
	public boolean Check(int traineeId, String mName) throws ModuleException {
		// TODO Auto-generated method stub
		return dao.Check(traineeId, mName);
	}

}
