package com.cg.msms.bean;

public class AssessmentBean {
	
	private int idTrainee;
	private String moduleName;
	private int mpt;
	private int mtt;
	private int assessMarks;
	private double total;
	private int grade;

	public AssessmentBean() {
		
	}
	
	
	
	public AssessmentBean(int idTrainee, String moduleName, int mpt, int mtt,
			int assessMarks) {
		super();
		this.idTrainee = idTrainee;
		this.moduleName = moduleName;
		this.mpt = mpt;
		this.mtt = mtt;
		this.assessMarks = assessMarks;
	}



	public AssessmentBean(int idTrainee, String moduleName, int mpt, int mtt,
			int assessMarks, double total, int grade) {
		super();
		this.idTrainee = idTrainee;
		this.moduleName = moduleName;
		this.mpt = mpt;
		this.mtt = mtt;
		this.assessMarks = assessMarks;
		this.total = total;
		this.grade = grade;
	}

	public int getIdTrainee() {
		return idTrainee;
	}

	public void setIdTrainee(int idTrainee) {
		this.idTrainee = idTrainee;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public int getMpt() {
		return mpt;
	}

	public void setMpt(int mpt) {
		this.mpt = mpt;
	}

	public int getMtt() {
		return mtt;
	}

	public void setMtt(int mtt) {
		this.mtt = mtt;
	}

	public int getAssessMarks() {
		return assessMarks;
	}

	public void setAssessMarks(int assessMarks) {
		this.assessMarks = assessMarks;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return "AssessmentBean [idTrainee=" + idTrainee + ", moduleName="
				+ moduleName + ", mpt=" + mpt + ", mtt=" + mtt
				+ ", assessMarks=" + assessMarks + ", total=" + total
				+ ", grade=" + grade + "]";
	}
	
	
		
}
