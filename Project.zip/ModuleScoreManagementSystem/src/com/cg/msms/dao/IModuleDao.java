package com.cg.msms.dao;

import java.util.ArrayList;

import com.cg.msms.bean.AssessmentBean;
import com.cg.msms.exception.ModuleException;

public interface IModuleDao {
	
	
	public ArrayList<Integer> getId() throws ModuleException;
	public boolean Check(int traineeId, String mName) throws ModuleException;
	public boolean addDetails(AssessmentBean bean) throws ModuleException;
	public int getGrade(double total) throws ModuleException;
}
