package com.cg.msms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;







import com.cg.msms.bean.AssessmentBean;
import com.cg.msms.exception.ModuleException;
import com.cg.msms.utility.DBUtil;

public class ModuleDao implements IModuleDao {

	public ModuleDao() {
		
	}
	
	
	/*
	 * Method Name: getId
	 * Author: Shubham Awasthi
	 * Date: 22nd September 2017
	 * Description: Return an arraylist containing all Trainee Id's
	 * that are to be displayed in drop down menu while adding assessment details.
	 */
	
	
	
	
	@Override
	public ArrayList<Integer> getId() throws ModuleException {
		

		ArrayList<Integer> list = null;
		int traineeId;
		
		try(Connection con =DBUtil.getConnection()){
			
			//get trainee Ids from trainees table
			
			PreparedStatement pstm=con.prepareStatement("SELECT trainee_id from TRAINEES");
			ResultSet res=pstm.executeQuery();
			
			//adding trainee Id into arraylist
			
			if(res.next()==false)
			{
				
				throw new ModuleException("Sorry, No Trainee found.");
			}
			else
			{
				list = new ArrayList<Integer>();
				do
				{
				traineeId=res.getInt("trainee_id");
				list.add(traineeId);
				
				}while(res.next());
				
			}
			
			
		} catch (Exception e) {
			
			throw new ModuleException("Sorry Trainee Id's Cannot be fetched");
		}
		
		//returning list to caller
		return list;
		
		
	}
	
	
	
	/*
	 * Method Name: addDetails
	 * Author: Shubham Awasthi
	 * Date: 22nd September 2017
	 * Description: Add details of trainee i.e its module name and marks
	 * that gets further stored in AssessmentScore table.
	 */

	@Override
	public boolean addDetails(AssessmentBean bean) throws ModuleException {
		boolean flag= false;
		try(Connection con=DBUtil.getConnection())
		{
			
		    
			int TraineeId = bean.getIdTrainee();
			String mName= bean.getModuleName();
			int Mpt = bean.getMpt();
			int Mtt = bean.getMtt();
			int assignment = bean.getAssessMarks();
			
			double total =  Mpt*(0.7) + Mtt*(0.15) + (0.15)*assignment;
			
			int grade = getGrade(total);
		
			PreparedStatement pstm=con.prepareStatement("INSERT INTO ASSESSMENTSCORE VALUES(?,?,?,?,?,?,?)");
			pstm.setInt(1, TraineeId);
			pstm.setString(2, mName);
			pstm.setInt(3, Mpt);
			pstm.setInt(4, Mtt);
			pstm.setFloat(5, assignment);
			pstm.setDouble(6, total);
			pstm.setInt(7, grade);
			
			flag= pstm.execute();
			
			
			
		}
		catch(Exception e)
		{
			throw new ModuleException("Sorry Something Went wrong. Details cannot be entered into database");
		}
			
		System.out.println(!flag);
		return (!flag);
	}
	
	@Override
	public int getGrade(double total) throws ModuleException
	{
		int grade=0;
		

		if(total<60)
		 grade=0;
		else if(total>=60 && total<=69)
		grade=2;
		else if(total>=70 && total<=79)
		grade=3;
		else if(total>=80 && total<=89)
		grade=4;
		else if(total>=90 && total<=100)
		grade=5;
		

System.out.println(grade);
		return grade;
	}

	@Override
	public boolean Check(int traineeId, String mName) throws ModuleException {
		boolean check= false;
		
		try(Connection con= DBUtil.getConnection())
		{
			String str= "SELECT * from AssessmentScore WHERE trainee_id=? AND module_name=?";
			PreparedStatement pstm= con.prepareStatement(str);
			pstm.setInt(1, traineeId);
			pstm.setString(2, mName);
			ResultSet res = pstm.executeQuery();
			if(res.next()==true)
			{
				check = true;
			}
		}
		catch(Exception e)
		{
			
			throw new ModuleException("Something went wrong try again");
		}
		
		return check;
	}

}
