package com.cg.mun.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.cg.mun.bean.RegisterBean;
import com.cg.mun.exception.RegisterException;
import com.cg.mun.service.RegisterServiceImpl;

@WebServlet("*.do")
public class RechargeServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RechargeServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");   
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		String path = request.getServletPath().trim();
		
		switch (path)
		{
	case "/register.do" :
		
	   {
		   RegisterServiceImpl Service = null;
	   
	RegisterBean userbean = null;
	String target = "";
	/*HttpSession session = request.getSession(true);*/
	userbean = new RegisterBean(target, target, target, target,target);
	Service = new RegisterServiceImpl();
	String owner_name = request.getParameter("firstname").trim()+request.getParameter("middlename").trim()+request.getParameter("lastname").trim();
	String business_name= request.getParameter("businessname").trim();
	String email  = request.getParameter("emailid").trim();
	String mob  = request.getParameter("mobileno").trim();
	userbean.setOwner_name(owner_name);
	userbean.setBusinessname(business_name);
	userbean.setEmailid(email);
	userbean.setMobileno(mob);
	userbean.setIsactive("N");
	
	
	try {
		Service.registerFlat(userbean);
	} catch (RegisterException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
int rn=0;
rn=10000+(int)(Math.random()*10000);

session.setAttribute("userbean", userbean);
session.setAttribute("otp", rn);

RequestDispatcher dispatcher = request.getRequestDispatcher("success.jsp");   
dispatcher.forward(request, response);


	   }
	}

}
}
