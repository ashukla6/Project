package com.cg.mun.exception;

public class RegisterException extends Exception {

	public RegisterException() {
		// TODO Auto-generated constructor stub
	}

	public RegisterException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public RegisterException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public RegisterException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public RegisterException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
