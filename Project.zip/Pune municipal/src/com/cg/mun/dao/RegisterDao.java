package com.cg.mun.dao;

import com.cg.mun.bean.RegisterBean;
import com.cg.mun.exception.RegisterException;

public interface RegisterDao {

	public RegisterBean registerFlat(RegisterBean user) throws RegisterException;
	public void updateFlat(String email) throws RegisterException;

}
