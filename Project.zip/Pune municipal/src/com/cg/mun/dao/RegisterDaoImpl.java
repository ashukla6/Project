package com.cg.mun.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;



import com.cg.mun.bean.RegisterBean;
import com.cg.mun.exception.RegisterException;
import com.cg.mun.utility.ConnectionUtil;

public class RegisterDaoImpl implements RegisterDao {

	public RegisterDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public RegisterBean registerFlat(RegisterBean user)
			throws RegisterException {
int firmNo=0;
		
		try(Connection con=ConnectionUtil.getConnection())
		{
			
		    //get flat details
			String ownername     = user.getOwner_name();
		    String businessname =user.getBusinessname();
		    String email =user.getEmailid();
		    String mobileno = user.getMobileno();
		    //char isactive = user.getIsactive();
			
		    //get sequence number assign to flatRegisterationId
			
			Statement stm=con.createStatement();
			ResultSet res=stm.executeQuery(IQuery.GETSEQUENCEID);
			
			//myLogger.info("Trying to generate id by seq");
			
			if(res.next()==false)
			{
				//myLogger.fatal("Exception while generating seq value");
				throw new RegisterException("Could not Register Flat. RegNo Generation failed.");
			}
			
			firmNo=res.getInt(1);
			
			//insert into database flat_registartion_details
			
			PreparedStatement pstm=con.prepareStatement(IQuery.INSERTQUERY);
			pstm.setInt(1, firmNo);

			pstm.setString(2,ownername);
			pstm.setString(3,businessname);
			pstm.setString(4,email);
			pstm.setString(5,mobileno);
			pstm.setString(6,"n");
			
			
			//myLogger.info("Trying to add flat registration details to database.");
			
			pstm.execute();
			
			//myLogger.info("Adding flat registartion details to database done successfully.");
		}
		catch(Exception e)
		{
			//myLogger.fatal("Exception while trying to add flat registration details to database: "+e.getMessage());
			throw new RegisterException(e.getMessage());
		}
		
		user.setFirmid(firmNo);
		
		//return flat object to caller
		return user;
	}


	

	@Override
	public void updateFlat(String email) throws RegisterException {
		// TODO Auto-generated method stub
		try(Connection con = ConnectionUtil.getConnection())
		{
			PreparedStatement pstm=con.prepareStatement("update FIRMS_MASTER set isactive=? where email=?");
			
			pstm.setString(1, "y");
			pstm.setString(2, email);
			pstm.execute();
			
		}catch (Exception e) {
			
			throw new RegisterException(e.getMessage());
		}
		
		
	}

		
	}


