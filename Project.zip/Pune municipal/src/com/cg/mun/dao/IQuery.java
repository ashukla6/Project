package com.cg.mun.dao;

public interface IQuery {
	String GETSEQUENCEID = "SELECT seq_firm_master.NEXTVAL FROM dual";
	String INSERTQUERY="INSERT INTO FIRMS_MASTER VALUES(?,?,?,?,?,?)";
	

}
