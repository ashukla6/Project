package com.cg.mun.service;

import com.cg.mun.bean.RegisterBean;
import com.cg.mun.exception.RegisterException;

public interface RegisterService {
	public RegisterBean registerFlat(RegisterBean user) throws RegisterException;
	public void updateFlat(String email) throws RegisterException;


}
