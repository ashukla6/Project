package com.cg.mun.service;

import com.cg.mun.bean.RegisterBean;
import com.cg.mun.dao.RegisterDao;
import com.cg.mun.dao.RegisterDaoImpl;
import com.cg.mun.exception.RegisterException;

public class RegisterServiceImpl implements RegisterService {
	RegisterDao registerDao;

	public RegisterServiceImpl() {
		// TODO Auto-generated constructor stub
		registerDao=new RegisterDaoImpl();
	}

	@Override
	public RegisterBean registerFlat(RegisterBean user)
			throws RegisterException {
		// TODO Auto-generated method stub
		return registerDao.registerFlat(user);
	}

	@Override
	public void updateFlat(String user) throws RegisterException {
		// TODO Auto-generated method stub
		registerDao.updateFlat(user);
		
	}

}
