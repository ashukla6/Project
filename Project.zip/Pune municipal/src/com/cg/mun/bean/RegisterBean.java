package com.cg.mun.bean;

public class RegisterBean {

	public RegisterBean() {
		// TODO Auto-generated constructor stub
	}
	private int firmid;
	public RegisterBean(String owner_name, String businessname, String emailid,
			String mobileno, String isactive) {
		super();
		this.owner_name = owner_name;
		this.businessname = businessname;
		this.emailid = emailid;
		this.mobileno = mobileno;
		this.isactive = isactive;
	}
	public RegisterBean(int firmid, String owner_name, String businessname,
			String emailid, String mobileno, String isactive) {
		super();
		this.firmid = firmid;
		this.owner_name = owner_name;
		this.businessname = businessname;
		this.emailid = emailid;
		this.mobileno = mobileno;
		this.isactive = isactive;
	}
	@Override
	public String toString() {
		return "RegisterBean [owner_name=" + owner_name + ", businessname="
				+ businessname + ", emailid=" + emailid + ", mobileno="
				+ mobileno + ", isactive=" + isactive + "]";
	}
	public int getFirmid() {
		return firmid;
	}
	public void setFirmid(int firmid) {
		this.firmid = firmid;
	}
	private String owner_name;
	private String businessname;
	private String emailid;
	private String mobileno;
	private String isactive;
	public String getOwner_name() {
		return owner_name;
	}
	public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
	}
	public String getBusinessname() {
		return businessname;
	}
	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getIsactive() {
		return isactive;
	}
	public void setIsactive(String isactive) {
		this.isactive = isactive;
	}
	
}
